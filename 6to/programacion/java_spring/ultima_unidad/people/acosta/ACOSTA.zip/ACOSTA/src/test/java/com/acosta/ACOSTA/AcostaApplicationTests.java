package com.acosta.ACOSTA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcostaApplicationTests {

	@Test
	void contextLoads() {
	}

}
