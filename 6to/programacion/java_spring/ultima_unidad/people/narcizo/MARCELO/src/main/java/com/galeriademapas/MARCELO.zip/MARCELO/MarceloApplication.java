package com.galeriademapas.MARCELO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarceloApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarceloApplication.class, args);
	}

}
