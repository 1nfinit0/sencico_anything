package com.galeriademapas.MARCELO.model;
public class FormatImage {

	String format;

	public FormatImage(String format) {
		this.format = format;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}
	
	
}
